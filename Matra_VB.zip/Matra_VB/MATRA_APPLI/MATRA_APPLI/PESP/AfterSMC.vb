﻿Option Strict On
Option Explicit On

Imports System
Imports System.Runtime.InteropServices
Imports Preactor.Interop.PreactorObject
Imports Preactor

<ComVisible(True)> _
<Microsoft.VisualBasic.ComClass("43d27340-bf65-4dad-bb14-a44fbbbd6074", "bf35fe36-1e54-411f-b4ab-bbe097fb0efc")> _
Public Class AfterSMC
    Public Function Run(ByRef preactorComObject As PreactorObj, ByRef pespComObject As Object) As Integer

        Dim preactor As IPreactor = PreactorFactory.CreatePreactorObject(preactorComObject)
        Dim planningboard = preactor.PlanningBoard

        For i = 1 To preactor.RecordCount(Pr_Orders.Table)
            Dim record = planningboard.GetPreviousOperation(i, 1)
            If (record > 0) Then
                preactor.WriteField(Pr_Orders.IlotPrecedent, i, preactor.ReadFieldString(Pr_Orders.Resource_Group, record))

                If (preactor.ReadFieldString(Pr_Orders.Resource_Group, i) <> preactor.ReadFieldString(Pr_Orders.Resource_Group, record)) Then

                    If (preactor.ReadFieldString(Pr_Orders.Table_Attribute_1, i) <> "PRIO_PROD") Then
                        preactor.WriteField(Pr_Orders.TempsAttente, i, 4 / 24.0)
                    Else
                        preactor.WriteField(Pr_Orders.TempsAttente, i, 2 / 24.0)
                    End If

                Else
                    preactor.WriteField(Pr_Orders.IlotPrecedent, i, preactor.ReadFieldString(Pr_Orders.Resource_Group, i))
                    preactor.WriteField(Pr_Orders.TempsAttente, i, 0.0)
                End If
            Else
                preactor.WriteField(Pr_Orders.IlotPrecedent, i, preactor.ReadFieldString(Pr_Orders.Resource_Group, i))
                preactor.WriteField(Pr_Orders.TempsAttente, i, 0.0)
            End If



            If (preactor.ReadFieldString(Pr_Orders.Table_Attribute_1, i) = "OF_BLOQUE") Then
                planningboard.UnallocateOperation(i, OperationSelection.ThisOperation)
                preactor.WriteField(Pr_Orders.Resource, i, -1)
                preactor.WriteField(Pr_Orders.Start_Time, i, -1)
                preactor.WriteField(Pr_Orders.Setup_Start, i, -1)
                preactor.WriteField(Pr_Orders.End_Time, i, -1)
                preactor.WriteField(Pr_Orders.Table, "Planifier", i, 0)
            End If

            'Dim Id = preactor.ReadFieldString(Pr_Orders.Identifiant, i)
            'Dim RecBOMId = preactor.FindMatchingRecord(Pr_Bill_of_Materials.OF_NumOperation, 0, Id)

            'If RecBOMId > 0 Then
            '    preactor.WriteField(Pr_Orders.Sous_ensemble, i, 0)
            'Else
            '    preactor.WriteField(Pr_Orders.Sous_ensemble, i, 1)
            'End If
            preactor.WriteField(Pr_Orders.Sous_ensemble, i, 1)
        Next


        preactor.Clear("Lien")


        ''preactor.Commit(Pr_Order_Links.Table, "SCHEDULE")
        '''Recuperation des bons orders links
        ''preactor.Load(Pr_Order_Links.Table, "SCHEDULE")
        ''preactor.Load(Pr_Orders.Table, "SCHEDULE")
        Pr_Order_Links.Init_List()
        Pr_Orders.Init_List2()
        Pr_Demand.Init_List()
        Dim ListLinks = Pr_Order_Links.ToList
        Dim ListOrders = Pr_Orders.ToList
        Dim ListOrders2 = Pr_Demand.ToList


        Dim query10 = From link In ListLinks
                      Join Order In ListOrders
                                     On Order.Number Equals link.From_Internal_Supply_Order
                      Join Demand In ListOrders2
                                    On Demand.Number Equals link.To_External_Demand_Order
                      Order By Demand.Demand_Date Descending
                      Select Order.Order_No.ToString + ";" + Demand.Demand_Date.ToString + ";" + Demand.Order_No.ToString

        query10 = query10.Distinct

        Dim index = 0
        Dim OFLie = ""
        Dim ListVariable = New List(Of Variables.AffectationDateCommande)

        For Each item In query10
            Dim Variable As Variables.AffectationDateCommande = New Variables.AffectationDateCommande
            Variable.Ordre = item.Split(";"c)(0).ToString
            Variable.DateOrdre = Convert.ToDateTime(item.Split(";"c)(1))
            Variable.Commande = item.Split(";"c)(2).ToString
            ListVariable.Add(Variable)
        Next

        index = 0

        For Each item In ListVariable

            Dim Record = preactor.FindMatchingRecord(Pr_Orders.Order_No, 0, item.Ordre)





            If (Record > 0) Then
                preactor.WriteField(Pr_Orders.Sous_ensemble, Record, 0)
                Dim ListRecord = New List(Of String)
                ParcoursOperation2(ListRecord, Record, preactor, planningboard)

                ListRecord.Add(Record.ToString)


                For Each item2 In ListRecord
                    preactor.WriteField(Pr_Orders.Date_Attribute_2, Convert.ToInt32(item2), item.DateOrdre)
                Next

                For Each item3 In ListRecord

                    Dim Record5 = preactor.CreateRecord("Lien")
                    Dim RecordCommande = preactor.FindMatchingRecord(Pr_Demand.Order_No, 0, item.Commande)
                    Dim Commande = preactor.ReadFieldInt(Pr_Demand.Number, RecordCommande)
                    Dim Ordre = preactor.ReadFieldInt(Pr_Orders.Number, Convert.ToInt32(item3))


                    preactor.WriteField("Lien", "RecordCommande", Record5, Commande)
                    preactor.WriteField("Lien", "RecordOF", Record5, Ordre)
                    preactor.WriteField(Pr_Orders.Table, "Commande", Convert.ToInt32(item3), item.Commande)

                Next


            End If
            ' While (recordOF > 0)


            '  recordOF = preactor.FindMatchingRecord(Pr_Orders.Order_No, recordOF, preactor.ReadFieldString(Pr_Orders.Order_No, recordOF))
            'End While









            'On affecte aux OF qui sont liés par la commande 

        Next


        preactor.Commit("Lien")


        For i = 1 To preactor.RecordCount(Pr_Orders.Table)
            preactor.WriteField(Pr_Orders.Priority, i, 999999)
            If (preactor.ReadFieldString(Pr_Orders.CodeCondition, i) = "SAV") Then
                preactor.WriteField(Pr_Orders.Sous_ensemble, i, 0)
            End If

        Next

        Dim query = From order In ListOrders
                    Where order.Statut_Operation = "Partiellement declare" AndAlso order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Table_Attribute_1 = "PRIO_PROD" AndAlso order.Belongs_to_Order_No = "PARENT"
                    Order By order.Latest_Start_Date
                    Select order
        Dim priorite = 0

        'On recherce les partiellement badgé
        For Each Item In query
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If


        Next


        Dim query2 = From order In ListOrders
                     Where order.Statut_Operation = "Partiellement declare" AndAlso order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Belongs_to_Order_No = "PARENT"
                     Order By order.Latest_Start_Date
                     Select order


        'On recherce les partiellement badgé
        For Each Item In query2
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If


        Next


        Dim query3 = From order In ListOrders
                     Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Table_Attribute_1 = "PRIO_PROD" AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.Client.Contains("PROTO") AndAlso order.Statut_Ordre = "Debute"
                     Order By order.Latest_Start_Date
                     Select order


        'On recherce les partiellement badgé
        For Each Item In query3
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If


        Next








        Dim query5 = From order In ListOrders
                     Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Table_Attribute_1 = "PRIO_PROD" AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.CodeCondition = "SAV" AndAlso order.Statut_Ordre = "Debute"
                     Order By order.Latest_Start_Date
                     Select order


        'On recherce les partiellement badgé
        For Each Item In query5
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If


        Next






        Dim query7 = From order In ListOrders
                     Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Table_Attribute_1 = "PRIO_PROD" AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.Statut_Ordre = "Debute"
                     Order By order.Latest_Start_Date
                     Select order


        'On recherce les partiellement badgé
        For Each Item In query7
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If


        Next





        Dim query9 = From order In ListOrders
                     Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.Client.Contains("PROTO") AndAlso order.Statut_Ordre = "Debute"
                     Order By order.Latest_Start_Date
                     Select order


        'On recherce les partiellement badgé
        For Each Item In query9
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If


        Next


        Dim query4 = From order In ListOrders
                     Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Table_Attribute_1 = "PRIO_PROD" AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.Client.Contains("PROTO") AndAlso order.Statut_Ordre = "Reserve"
                     Order By order.Latest_Start_Date
                     Select order


        'On recherce les partiellement badgé
        For Each Item In query4
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If


        Next


        Dim query6 = From order In ListOrders
                     Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Table_Attribute_1 = "PRIO_PROD" AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.CodeCondition = "SAV" AndAlso order.Statut_Ordre = "Reserve"
                     Order By order.Latest_Start_Date
                     Select order


        'On recherce les partiellement badgé
        For Each Item In query6
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If

        Next

        Dim query8 = From order In ListOrders
                     Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Table_Attribute_1 = "PRIO_PROD" AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.Statut_Ordre = "Reserve"
                     Order By order.Latest_Start_Date
                     Select order


        'On recherce les partiellement badgé
        For Each Item In query8
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If


        Next

        Dim query11 = From order In ListOrders
                      Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.Client.Contains("PROTO") AndAlso order.Statut_Ordre = "Reserve"
                      Order By order.Latest_Start_Date
                      Select order


        'On recherce les partiellement badgé
        For Each Item In query11
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If


        Next




        Dim query12 = From order In ListOrders
                      Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Table_Attribute_1 = "PRIO_PROD" AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.Client.Contains("PROTO")
                      Order By order.Latest_Start_Date
                      Select order


        'On recherce les partiellement badgé
        For Each Item In query12
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1

            End If

        Next



        Dim query13 = From order In ListOrders
                      Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Table_Attribute_1 = "PRIO_PROD" AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.CodeCondition = "SAV"
                      Order By order.Latest_Start_Date
                      Select order

        'On recherce les partiellement badgé
        For Each Item In query13
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If


        Next




        Dim query14 = From order In ListOrders
                      Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Table_Attribute_1 = "PRIO_PROD" AndAlso order.Belongs_to_Order_No = "PARENT"
                      Order By order.Latest_Start_Date
                      Select order


        'On recherce les partiellement badgé
        For Each Item In query14
            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If


        Next




        Dim query15 = From order In ListOrders
                      Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.CodeCondition = "SAV"
                      Order By order.Latest_Start_Date
                      Select order
        'On recherce les partiellement badgé
        For Each Item In query15

            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If
        Next




        Dim query17 = From order In ListOrders
                      Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.Statut_Ordre = "Debute"
                      Order By order.Latest_Start_Date
                      Select order
        'On recherce les partiellement badgé
        For Each Item In query17

            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If
        Next


        Dim query18 = From order In ListOrders
                      Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Belongs_to_Order_No = "PARENT" AndAlso order.Statut_Ordre = "Reserve"
                      Order By order.Latest_Start_Date
                      Select order
        'On recherce les partiellement badgé
        For Each Item In query18

            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If
        Next





        Dim query19 = From order In ListOrders
                      Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Statut_Ordre = "Debute"
                      Order By order.Latest_Start_Date
                      Select order
        'On recherce les partiellement badgé
        For Each Item In query19

            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If
        Next


        Dim query20 = From order In ListOrders
                      Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False AndAlso order.Statut_Ordre = "Reserve"
                      Order By order.Latest_Start_Date
                      Select order
        'On recherce les partiellement badgé
        For Each Item In query20

            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If
        Next




        Dim query21 = From order In ListOrders
                      Where order.Table_Attribute_1 <> "OF_BLOQUE" AndAlso order.SupportVisualisation = False
                      Order By order.Latest_Start_Date
                      Select order
        'On recherce les partiellement badgé
        For Each Item In query21

            If (preactor.ReadFieldInt(Pr_Orders.Priority, Item.Record) = 999999) Then
                preactor.WriteField(Pr_Orders.Priority, Item.Record, priorite)
                priorite = priorite + 1
            End If
        Next



        Return 0
    End Function


    Friend Function ParcoursOperation2(ByRef ListRecord As List(Of String), CurrentRecord As Integer, ByVal Preactor As IPreactor, planningboard As IPlanningBoard) As List(Of String)



        Dim NextOPeration = planningboard.GetNextOperation(CurrentRecord, 1)
        If (NextOPeration > 0) Then
            ListRecord.Add(NextOPeration.ToString)
        End If

        If (NextOPeration > 0) Then

            ParcoursOperation2(ListRecord, NextOPeration, Preactor, planningboard)
        Else
            ParcoursOperationP2(ListRecord, CurrentRecord, Preactor, planningboard, 1)
        End If



        Return ListRecord

    End Function

    Friend Function ParcoursOperationP2(ByRef ListRecord As List(Of String), CurrentRecord As Integer, ByVal Preactor As IPreactor, planningboard As IPlanningBoard, Index As Integer) As List(Of String)



        Dim PreviousOPeration = planningboard.GetPreviousOperation(CurrentRecord, Index)

        While (PreviousOPeration > 0)


            If (PreviousOPeration > 0) Then
                ListRecord.Add(PreviousOPeration.ToString)
            End If

            If (PreviousOPeration > 0) Then
                ParcoursOperationP2(ListRecord, PreviousOPeration, Preactor, planningboard, 1)
            End If
            Index = Index + 1
            PreviousOPeration = planningboard.GetPreviousOperation(CurrentRecord, Index)
        End While

        Return ListRecord

    End Function

End Class
